from database import get_connection

#journal entries

def journal_entries(portfolio_id):
    print("*"*18,"JOURNAL ENTRIES","*"*18)
    print("_"*53)
    conn=get_connection()
    cursor=conn.cursor()
    query="SELECT name,quantity,price,total FROM buy WHERE portfolio_id=%s"
    cursor.execute(query,(portfolio_id,))
    result=cursor.fetchall()
    print("-"*20,"BUY ENTRIES","-"*20)
    print("{:^15}|{:^10}|{:^10}||{:^15}".format("NAME","QUANT","PRICE","TOTAL"))
    for i in result:
         print("{:^15}|{:^10}|{:^10}||{:^15}".format(i[0],str(i[1]),str(i[2]),str(i[3])))
    print()
    query="SELECT name,quantity,price,total FROM sell WHERE portfolio_id=%s"
    cursor.execute(query,(portfolio_id,))
    result=cursor.fetchall()
    print("_"*53)
    print("-"*20,"SELL ENTRIES","-"*20)
    print("{:^15}|{:^10}|{:^10}||{:^15}".format("NAME","QUANT","PRICE","TOTAL"))
    for i in result:
         print("{:^15}|{:^10}|{:^10}||{:^15}".format(i[0],str(i[1]),str(i[2]),str(i[3])))
    cursor.close()
    conn.close()





