from database import get_connection
def holdings(portfolio_id):
    conn=get_connection()
    cursor=conn.cursor()
    cursor.execute("SELECT name, quantity, price FROM buy WHERE portfolio_id=%s",(portfolio_id,))
    buy_data={row[0]:{"quantity":row[1],"price":row[2]}for row in cursor.fetchall()} 
    cursor.execute("SELECT name, quantity FROM sell WHERE portfolio_id=%s",(portfolio_id,))
    sell_data={row[0]:row[1] for row in cursor.fetchall()}
    filtered=[]
    for name, b_data in buy_data.items():
        total_buy_quantity=b_data["quantity"]
        avg_price=b_data["price"]
        sell_quantity=sell_data.get(name,0)
        net_quantity=total_buy_quantity-sell_quantity
        if net_quantity>0:
            total=avg_price*net_quantity
            filtered.append((name,net_quantity,avg_price,total,portfolio_id))
    cursor.execute("DELETE FROM holdings WHERE portfolio_id=%s",(portfolio_id,))
    cursor.executemany("INSERT INTO holdings (name, net_quantity, avg_price, total, portfolio_id) VALUES(%s,%s,%s,%s,%s)",filtered)
    conn.commit()
    print(f"updated {len(filtered)} holdings.")
    cursor.close()
    conn.close()
        
        

