from database import get_connection
#unrealised profit and loss
from current_prices import current_prices
def unrealised_pl(portfolio_id):
    print("*"*20,"UNREALISED P&L","*"*20)
    conn=get_connection()
    cursor=conn.cursor()
    cursor.execute("SELECT name, net_quantity, avg_price, total FROM holdings WHERE portfolio_id=%s",(portfolio_id,))
    result=cursor.fetchall()
    print("{:^15}|{:^10}|{:^10}|{:^15}|{:^10}|{:^15}||{:^10}|{:^10}".format("NAME","QUANT","PRICE","TOTAL","CURRENT","NEW TOTAL","UNRELISED P/L","RETURN"))
    for name,quantity,price,buy_total in result:
        current_price=current_prices(name)
        quantity=float(quantity)
        buy_total=float(buy_total)
        new_total=current_price*quantity
        prfit_loss=new_total-buy_total
        return_percentage=round(((current_price-float(price))/float(price))*100,2)
        print("{:^15}|{:^10}|{:^10}|{:^15}|{:^10}|{:^15}||{:^10}|{:^10}".format(name,str(quantity),str(price),str(buy_total),str(current_price),str(new_total),str(prfit_loss),str(return_percentage)+"%"))
    cursor.close()
    conn.close()