from database import get_connection

def sell_stock(name,quantity,price,portfolio_id):
    total=price*quantity
    conn=get_connection()
    cursor=conn.cursor()
    cursor.execute("SELECT quantity, price FROM sell WHERE name=%s AND portfolio_id=%s",(name,portfolio_id,))
    result=cursor.fetchone()
    if result:
        existing_quantity, existing_price = result
        new_quantity = existing_quantity + quantity
        total_existing_cost = existing_quantity * existing_price
        total_new_cost = quantity * price
        new_price = (total_existing_cost + total_new_cost) / new_quantity
        new_total = new_quantity * new_price
        new_query="UPDATE sell SET quantity=%s,price=%s,total=%s WHERE name=%s AND portfolio_id=%s"
        cursor.execute(new_query,(new_quantity,round(new_price,2),round(new_total,2),name,portfolio_id))
        conn.commit()
        print(f"'{name}' updated in the protfolio, quantyity:{quantity}|price:{price}|total:{total}")
    else:
      query="INSERT INTO sell(name,quantity,price,total,portfolio_id) VALUES(%s,%s,%s,%s,%s)"
      cursor.execute(query,(name,quantity,price,total,portfolio_id))
      conn.commit()
      print(f"you have sold ₹{total} worth of '{name}'.")
      print(f"Sell entry of '{name}' has been successfully recorded!")
      print(f"quantoty:{quantity},|price:{price}|total:{total}")
      cursor.close()
      conn.close()

