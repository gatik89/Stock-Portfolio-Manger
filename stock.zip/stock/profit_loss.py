from database import get_connection
def profit_loss():
    conn=get_connection()
    cursor=conn.cursor()
    query="""SELECT buy.name,buy.quantity,buy.price,buy.total,sell.name,sell.quantity,sell.price,sell.total
            FROM buy
            JOIN sell ON buy.name=sell.name"""    
    cursor.execute(query)
    result=cursor.fetchall()
    print("{:^15}|{:^10}|{:^10}|{:^15}|{:^15}|{:^10}|{:^10}|{:^15}||{:^15}".format("BUY NAME","BUY QUANT","BUY PRICE","BUY TOTAL","SELL NAME","SELL QUANT","SELL PRICE","SELL TOTAL","P/L","RETURN"))
    for i in result:
         buy_total=i[3]
         sell_total=i[7]
         gain_loss=sell_total-buy_total
         return_percentage=round(((sell_total-buy_total)/buy_total)*100,2)
         print("{:^15}|{:^10}|{:^10}|{:^15}|{:^15}|{:^10}|{:^10}|{:^15}||{:^15}".format(i[0],str(i[1]),str(i[2]),str(buy_total),i[4],str(i[5]),str(i[6]),str(sell_total),str(gain_loss),str(return_percentage)))

    cursor.close()
    conn.close()
