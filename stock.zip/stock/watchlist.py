from database import get_connection
from current_prices import current_prices


#add to list 


from database import get_connection
def add_to_list(name,trigger_price,portfolio_id):
    conn=get_connection()
    cursor=conn.cursor()
    query=("SELECT * FROM watchlist WHERE name=%s AND portfolio_id=%s")
    cursor.execute(query,(name,portfolio_id,))
    result=cursor.fetchone()
    if result:
        update_query=("UPDATE watchlist SET trigger_price=%s, date=NOW() WHERE name=%s AND portfolio_id=%s")
        cursor.execute(update_query,(trigger_price,name,portfolio_id))
    else:
        insert_query=("INSERT INTO watchlist(name,trigger_price,portfolio_id)VALUES(%s,%s,%s)")
        cursor.execute(insert_query,(name,trigger_price,portfolio_id,))
        print(f"'{name}' added to your watchlist at a trigger price of ₹{trigger_price}")
    conn.commit()
    cursor.close()
    conn.close()
def add_to_list_input(portfolio_id):
 try:
    num_of_stocks=int(input("Enter the number of stocks you want add to your watchlist:- "))
    for i in range(num_of_stocks):
        print(f"{i+1} entry out of {num_of_stocks}")
        name=input("Enter the valid ticker name of the stock:- ")
        trigger_price_input=input(f"Enter the trriger price level of '{name}' :- ")
        add_to_list(name,trigger_price_input,portfolio_id)
 except ValueError:
    print("Enter valid input.")


#view list


def view_list(portfolio_id):
    conn=get_connection()
    cursor=conn.cursor()
    query=("SELECT name,date,trigger_price FROM watchlist WHERE portfolio_id=%s")
    cursor.execute(query,(portfolio_id,))
    result=cursor.fetchall()
    print("{:^13}|{:^13}|{:^15}|{:^15}|{:^15}".format("NAME","DATE","TRIGGER PRICE","CURRENT PRICES","%DIFFEReNCE"))
    for name,date,trigger_price in result:
        current_price=current_prices(name)
        differance=round(((trigger_price-current_price)/trigger_price)*100,1)
        print("{:^13}|{:^13}|{:^15}|{:^15}|{:^15}".format(name, str(date), str(trigger_price), str(current_price),str(differance)))

    cursor.close()
    conn.close()

# remove from list 

def remove_from_list(name,portfolio_id):
    conn=get_connection()
    cursor=conn.cursor()
    query=("DELETE FROM watchlist WHERE name=%s AND portfolio_id=%s")
    cursor.execute(query,(name,portfolio_id,))
    conn.commit()
    print(f"'{name}' succesfully removed from your watchlist.")
    cursor.close()
    conn.close()
def remove_from_list_input(portfolio_id):
 try:
    num_of_stocks_removed=int(input("Enter the number of stocks you want remove from your watchlist:- "))
    for i in range(num_of_stocks_removed):
        print(f"{i+1} out of {num_of_stocks_removed} entries left")
        name=input("Enter the name of stock:-")
        remove_from_list(name,portfolio_id)
 except ValueError:
    print("something went wrong")








