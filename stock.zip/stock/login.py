from database import get_connection
from mysql.connector import IntegrityError


#new user id 
def register_user():
    conn=get_connection()
    cursor=conn.cursor()
    new_name=input("Enter your name:- ")
    while True:
      new_portfolio_id=input("Create your 6 digit portfolio ID:- ")
      if len(new_portfolio_id)==6 or new_portfolio_id.isdigit():
         break
      else:
        print("Portfolio id must be of 6 digits.")
      new_portfolio_pass=input("Enter your 4 digit pin:- ")
      if len(new_portfolio_pass)==4 or new_portfolio_pass.isdigit():
         break
      else:
        print("Portfolio id must be of 4 digits.")
      try:
       cursor.execute("INSERT INTO login (name,portfolio_id, portfolio_pass)VALUES(%s,%s,%s,)",(new_name,new_portfolio_id,new_portfolio_pass))
       conn.commit()
       print(f"Hey {new_name}, your accoint is created succesfully!")
      except IntegrityError as e:
        print("User already exists try again.")
      finally:
        cursor.close()
        conn.close()

   #user login
def user_login(portfolio_id, portfolio_pass):
    conn=get_connection()
    cursor=conn.cursor()
    cursor.execute("SELECT* FROM login WHERE portfolio_id=%s AND portfolio_pass=%s",(portfolio_id,portfolio_pass))
    result=cursor.fetchone()
    cursor.close()
    conn.close()
    if result:
         name=result[1]
         print(f"welcome {name}!, How are you doing today? ")
         return True
    else:
         print("Invalid password.")




