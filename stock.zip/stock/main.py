# Import the login module for user authentication
from login import user_login, register_user

logged_in_user = None  # Global variable to store logged in user's ID

# User authentication loop
while True:
    print("\n--- Welcome to the Stock Portfolio System ---")
    print("1. Login to an existing account")
    print("2. Create a new account")
    login_input = input("Enter your preference: ").strip()

    if login_input == "1":
        # Allow up to 3 login attempts
        attempts = 3
        while attempts > 0:
            portfolio_id = input("Enter your Portfolio ID: ").strip()
            if not portfolio_id:
                print("Please enter a valid Portfolio ID.")
                continue

            portfolio_password = input("Enter your Portfolio Password: ").strip()
            if not portfolio_password:
                print("Password cannot be empty. Try again.")
                continue

            if user_login(portfolio_id, portfolio_password):
                logged_in_user = portfolio_id
                break
            else:
                attempts -= 1
                print(f"Incorrect credentials. Attempts left: {attempts}")

        if attempts == 0:
            print("Too many failed attempts. Please try again later.")
            continue

    elif login_input == "2":
        register_user()
        continue

    else:
        print("Invalid input. Please choose '1' or '2'.")
        continue

    # Home page loop after successful login
    while True:
        print("\n" + "-" * 5 + " HOME " + "-" * 5)
        print("1. {:^14}".format("BUY"))
        print("2. {:^14}".format("SELL"))
        print("3. {:^14}".format("PROFIT/LOSS"))
        print("4. {:^14}".format("WATCHLIST"))
        print("5. {:^14}".format("STOCK REPORT"))
        print("6. {:^14}".format("UNREALISED P/L"))
        print("7. {:^14}".format("SEARCH STOCK"))

        inp3 = input("Enter the index number from above to perform an activity: ").strip()

        # Buy Entry
        if inp3 == "1":
            from buy_entry import buy_stock
            total_stock = int(input("Enter the number of shares bought today: "))
            for i in range(total_stock):
                print(f"\nEntry {i + 1} of {total_stock}")
                name = input("Enter the name of the bought stock: ")
                quantity = int(input(f"Enter the quantity bought of '{name}': "))
                price = float(input(f"Enter the price at which '{quantity}' shares of '{name}' were bought: "))
                buy_stock(name, quantity, price, logged_in_user)

        # Sell Entry
        elif inp3 == "2":
            from sell_entry import sell_stock
            total_stock_2 = int(input("Enter the number of stocks sold today: "))
            for i in range(total_stock_2):
                print(f"\nEntry {i + 1} of {total_stock_2}")
                name = input("Enter the name of the sold stock: ")
                quantity = int(input(f"Enter the quantity sold of '{name}': "))
                price = float(input(f"Enter the price at which '{quantity}' shares of '{name}' were sold: "))
                sell_stock(name, quantity, price, logged_in_user)

        # Profit/Loss Journal
        elif inp3 == "3":
            from profit_loss import profit_loss
            profit_loss()

        # Watchlist Section
        elif inp3 == "4":
            while True:
                print("\n" + "-" * 5 + " WATCH LIST " + "-" * 5)
                print("1. {:^14}".format("ADD TO LIST"))
                print("2. {:^14}".format("VIEW LIST"))
                watchlist_input = input("Enter your choice (1 or 2): ").strip()

                if watchlist_input == "1":
                    from watchlist import add_to_list_input, view_list
                    add_to_list_input(logged_in_user)
                    view_list(logged_in_user)

                elif watchlist_input == "2":
                    from watchlist import view_list
                    view_list(logged_in_user)

                # Watchlist options
                inp5 = input("To add, remove, or exit watchlist enter 1, 2, or 3 respectively: ").strip()
                if inp5 == "1":
                    from watchlist import add_to_list_input
                    add_to_list_input(logged_in_user)
                elif inp5 == "2":
                    from watchlist import remove_from_list_input
                    remove_from_list_input(logged_in_user)
                elif inp5 == "3":
                    print("Don't have a good day — Have a great day!")
                    exit()
                else:
                    print("Invalid input. Try again.")

        # Stock Journal Entries
        elif inp3 == "5":
            from journal import journal_entries
            journal_entries(logged_in_user)

        # Unrealised Profit & Loss
        elif inp3 == "6":
            from holdings import holdings
            holdings(logged_in_user)
            from unrealisedpl import unrealised_pl
            unrealised_pl(logged_in_user)

        # Stock Fundamentals Search
        elif inp3 == "7":
            from fundamentals import analyze_stock
            analyze_stock()

        # Exit or Continue
        inp4 = input("\nPress Enter to return to the main menu or type 'end' to exit: ").strip().lower()
        if inp4 == "end":
            print("Goodbye GK, have a nice day!")
            break





